export default {
  actifs: {
    
    recherche: {
      title: 'Ordres de service',
      searchRapportT: 'Rapport de service',
      brigade: 'Brigade',
      numSerie: 'N° série',
      annee: 'Année',
      journeeDu: 'Journée du',
      rechercher: 'Rechercher',
      nOS: 'N° OS',
      conf: 'Conf',
      add: 'Add',
      description: 'Description',
      Agents: 'Agents',
      vehicules: 'Véhicules',
      chefEquipe: 'Chef d’équipe',
      Rapports: 'Rapports',
      PasDElements:
        'Aucun programme journalier ne correspond à votre recherche',
      unite: 'unité',
      errors: {
        champsSearcheRapportRequired:
          'Veuillez saisir au moins un critère de recherche',
      },
    }
    }
};
