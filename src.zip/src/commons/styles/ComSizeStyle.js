export const loginButton = {
  width: '50%',
  height: 50,
};

export const loginInput = {
  width: '50%',
  height: 50,
};
export const Input = {
  width: 280,
  height: 20,
};

export const loginHeaderImage = {
  width: 300,
  height: 100,
};

export const loadingIndicator = {
  width: '100%',
};

export const centerContainer = {
  width: '100%',
  height: '100%',
};

export const centeredText = {
  fontSize: 16,
};

export const card = {
  height: 150,
  width: 150,
};

export const badrPicker = {};

export const badrPickerTitle = {};

export const menuUserImage = {
  width: 100,
  height: 100,
};

export const smallInput = {
  width: 75,
};
export const mediumInput = {
  width: 150,
};
export const largeInput = {
  width: 300,
};

export const badrButtonIcon = {
  width: 280,
};
export const InputSize = {
  height: 20,
};

export const badrInputHeight = {
  height: 45,
};
