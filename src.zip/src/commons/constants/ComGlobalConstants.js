export const TYPE_SERVICE_SP = 'SP';
export const TYPE_SERVICE_UC = 'UC';
