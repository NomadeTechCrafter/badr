export const cardText = {
  fontWeight: 'bold',
  fontSize: 14,
  color: '#FFFFFF',
};

export const badrPicker = {
  fontSize: 20,
};

export const badrPickerTitle = {
  fontWeight: 'bold',
  fontSize: 18,
};
